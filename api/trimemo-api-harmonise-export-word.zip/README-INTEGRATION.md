# Trimémo – backend corrigé

Fichiers modifiés :
- `api/generate-plans.js`
- `api/generate-problematics.js`

Principes :
- maximum de 3 chapitres par partie ;
- maximum de 3 sections par chapitre ;
- maximum de 3 sous-sections par section ;
- structure interne variable selon la logique scientifique ;
- prise en compte de `project.problematiquePersonnelle` ;
- prise en compte de `project.planPersonnel` ou `providedPlan` ;
- conservation du plan fourni, structuré en JSON exploitable ;
- réponses d’erreur JSON explicites.

Déployer ces fichiers dans le même projet Vercel que le backend existant.
